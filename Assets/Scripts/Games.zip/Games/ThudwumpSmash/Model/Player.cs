﻿using UnityEngine;
using System.Collections;


namespace Games.ThudwumpSmash
{
public class Player : MonoBehaviour 
{
		public float smashingSpeed = 5;
		public bool smashable=true;

		public void Smash()
		{
			
		}

		public void SetPosition()
		{
			
		}

}
}
