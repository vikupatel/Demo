﻿using UnityEngine;
using System.Collections;

public interface IDamagable
{
	void Damage();
}
